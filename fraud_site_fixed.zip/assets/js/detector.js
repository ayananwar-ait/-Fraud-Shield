/* detector.js – Hybrid Fraud Detection Engine
   Implements the statistical + ML framework from the research paper
   Allenhouse Institute of Technology, Kanpur */

const FD = (function () {
  // Dataset constants (IEEE-CIS derived)
  const MU = 135.67, SIGMA = 250.42;
  const AVG_HOUR = 7, PEAK = 24;
  const MIN_FREQ = 1, MAX_FREQ = 10;

  function clamp(v, a, b) { return Math.min(Math.max(v, a), b); }
  function sigmoid(x) { return 1 / (1 + Math.exp(-x)); }

  function colorFor(v) {
    return v > 0.70 ? '#991f1f' : v > 0.45 ? '#7a4400' : '#2d6a12';
  }
  function barColor(v) {
    return v > 0.70 ? '#e24040' : v > 0.45 ? '#ef9f27' : '#1558a8';
  }

  function analyze(inputs) {
    const { amt, hour, freqCur, freqAvg, histFraud, histTotal, userMean, userStd, locKnown } = inputs;

    /* ── Step 1: Statistical Features ── */
    const Z = (amt - MU) / SIGMA;
    const ZS = clamp(Math.abs(Z) / 5, 0, 1);

    const pFraud = 0.08, pLegit = 0.92;
    const pXFraud = clamp(0.5 + 0.5 * (ZS - 0.5), 0.05, 0.99);
    const pXLegit = clamp(0.1 - 0.05 * ZS, 0.01, 0.3);
    const pX = pXFraud * pFraud + pXLegit * pLegit;
    const BF = clamp((pXFraud * pFraud) / pX, 0, 1);

    const CS = 0.75; // dataset-derived Pearson r

    const freqRatio = freqCur / Math.max(freqAvg, 1);
    const p1 = clamp(0.6 - 0.05 * (freqRatio - 1), 0.1, 0.8);
    const p2 = 0.25, p3 = clamp(1 - p1 - p2, 0.05, 0.5);
    const H = -(p1 * Math.log2(p1) + p2 * Math.log2(p2) + p3 * Math.log2(p3));
    const ES = clamp(H / 2, 0, 1);

    const rawT = freqCur / Math.max(freqAvg, 1);
    const FS = clamp((rawT - MIN_FREQ) / (MAX_FREQ - MIN_FREQ), 0, 1);

    const TS = clamp(Math.abs(hour - AVG_HOUR) / PEAK, 0, 1);
    const HR = clamp(histFraud / Math.max(histTotal, 1), 0, 1);

    /* ── Step 2: Statistical Score ── */
    const S = (ZS + BF + CS + ES + FS + TS + HR) / 7;

    /* ── Step 3: ML Predictions ── */
    const PRF   = clamp(0.5 + 0.45 * S + 0.05 * TS, 0, 1);
    const PXGB  = clamp(sigmoid(2.5 * S + 0.5 * TS + 0.3 * FS - 0.5 * (1 - BF)), 0, 1);
    const AIF   = clamp(0.4 + 0.55 * ZS + 0.1 * HR, 0, 1);
    const PAE   = clamp(0.3 + 0.6 * ZS + 0.15 * BF, 0, 1);
    const PLSTM = clamp(sigmoid(2.2 * S + 0.6 * TS), 0, 1);

    /* ── Step 4: Ensemble ML Score ── */
    const M = (PRF + PXGB + AIF + PAE + PLSTM) / 5;

    /* ── Step 5: Behavioral & Temporal ── */
    const rawB = Math.abs(amt - userMean) / Math.max(userStd, 1);
    const B = clamp(rawB / 5, 0, 1);
    const T = clamp(Math.abs(hour - 6.2) / 24, 0, 1);

    /* ── Final Risk ── */
    const Risk = 0.20 * S + 0.50 * M + 0.20 * B + 0.10 * T;

    return {
      // raw inputs
      amt, hour, freqCur, freqAvg, histFraud, histTotal, userMean, userStd, locKnown,
      // statistical features
      ZS, BF, CS, ES, FS, TS, HR,
      // scores
      S, PRF, PXGB, AIF, PAE, PLSTM, M, B, T, Risk,
      // helpers
      colorFor, barColor
    };
  }

  function verdict(Risk) {
    if (Risk >= 0.80) return {
      cls: 'v-fraud', icon: '⚠️',
      title: 'Fraudulent Transaction Detected',
      sub: `Risk score ${(Risk * 100).toFixed(1)}% exceeds optimal threshold θ* = 0.80 (ROC/Youden). Transaction blocked and flagged for investigation.`
    };
    if (Risk >= 0.48) return {
      cls: 'v-review', icon: '🔎',
      title: 'Investigation Required',
      sub: `Risk score ${(Risk * 100).toFixed(1)}% falls in review zone (0.48–0.80). Transaction routed to fraud analyst for manual review.`
    };
    return {
      cls: 'v-legit', icon: '✅',
      title: 'Legitimate Transaction',
      sub: `Risk score ${(Risk * 100).toFixed(1)}% is below threshold. Transaction approved.`
    };
  }

  return { analyze, verdict, colorFor, barColor };
})();
