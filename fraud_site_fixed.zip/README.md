# 🛡️ Hybrid Fraud Detection System

**A Hybrid Statistical–Machine Learning Framework for Adaptive Financial Fraud Detection in Real Time**

> Allenhouse Institute of Technology, Kanpur, India

[![GitHub Pages](https://img.shields.io/badge/GitHub%20Pages-Live-brightgreen?logo=github)](https://your-username.github.io/fraud-detection-site/)

---

## 📄 About

This website accompanies the research paper:

> *A Hybrid Statistical–Machine Learning Framework for Adaptive Financial Fraud Detection in Real Time*  
> Allenhouse Institute of Technology, Kanpur, India

The framework combines **statistical analysis**, **ensemble machine learning**, and **Explainable AI (XAI)** for real-time financial fraud detection, evaluated on the [IEEE-CIS Fraud Detection Dataset](https://www.kaggle.com/c/ieee-fraud-detection).

---

## 🗂️ File Structure

```
fraud-detection-site/
├── index.html              ← Home page
├── about.html              ← Paper overview & motivation
├── methodology.html        ← Full mathematical methodology
├── demo.html               ← Interactive fraud detection demo
├── results.html            ← Results & evaluation
├── README.md               ← This file
└── assets/
    ├── css/
    │   └── style.css       ← Global stylesheet
    └── js/
        ├── nav.js          ← Navigation behaviour
        └── detector.js     ← Fraud detection engine
```

---

## 🚀 Deploy to GitHub Pages

### Option 1 — Simple Upload

1. Go to your GitHub repository
2. Click **Add file → Upload files**
3. Upload all files and folders (maintain the structure above)
4. Go to **Settings → Pages → Source → main branch / root**
5. Your site is live at `https://your-username.github.io/repo-name/`

### Option 2 — Git Clone

```bash
# Clone or create your repo
git clone https://github.com/your-username/fraud-detection-site.git
cd fraud-detection-site

# Copy all files here, then:
git add .
git commit -m "Initial commit: Hybrid Fraud Detection website"
git push origin main
```

Then enable GitHub Pages in **Repository Settings → Pages**.

---

## 🔬 Framework Summary

| Component | Details |
|-----------|---------|
| **Statistical Features** | Z-score, Bayesian probability, Pearson correlation, entropy, frequency rating, time-series anomaly, historical risk |
| **ML Models** | Random Forest, XGBoost, Isolation Forest, Autoencoder, LSTM |
| **Final Risk Formula** | `Risk = 0.20·S + 0.50·M + 0.20·B + 0.10·T` |
| **XAI** | SHAP (global) + LIME (local) |
| **Dataset** | IEEE-CIS Fraud Detection (Kaggle) |
| **Decision Threshold** | θ* = 0.80 (ROC/Youden optimal) |

---

## 📊 Decision Logic

| Risk Score | Decision |
|------------|----------|
| ≥ 0.80     | 🔴 **Fraudulent** — Block transaction |
| 0.48–0.80  | 🟡 **Review Required** — Route to analyst |
| < 0.48     | 🟢 **Legitimate** — Approve |

---

## 🛠️ Tech Stack

- Pure HTML5, CSS3, Vanilla JavaScript
- No build tools, no dependencies, no backend required
- Works with any static hosting (GitHub Pages, Netlify, Vercel)
- Fully responsive (mobile + desktop)

---

## 📚 Key References

1. IEEE-CIS Fraud Detection Dataset — Kaggle / IEEE Computational Intelligence Society
2. SHAP: Lundberg & Lee (2017) — Shapley Additive Explanations
3. LIME: Ribeiro et al. (2016) — Local Interpretable Model-Agnostic Explanations
4. XGBoost: Chen & Guestrin (2016)
5. Isolation Forest: Liu et al. (2008)

---

*Allenhouse Institute of Technology, Kanpur, India*
